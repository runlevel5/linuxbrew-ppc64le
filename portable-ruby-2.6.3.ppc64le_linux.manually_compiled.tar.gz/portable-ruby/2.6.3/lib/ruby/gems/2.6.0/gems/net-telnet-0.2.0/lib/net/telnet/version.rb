module Net
  class Telnet
    VERSION = "0.2.0"
  end
end
